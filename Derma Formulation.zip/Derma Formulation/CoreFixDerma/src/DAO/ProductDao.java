package DAO;

import java.util.List;

import POJO.Product;

public interface ProductDao {

	 public  boolean addProduct(Product p);
	 public boolean updateProduct(Product p);
	 public  boolean deleteProduct(String name);

	 public Product searchById(int ProductId);
	 public  List<Product> getAllProducts();
	 public  List<Product> getProductByName(String name);
	}
