package Test;

import java.util.Arrays;
import java.util.List;

import DAO.ProductDao;
import IMPL.ProductDaoImpl;
import POJO.Ingredient;
import POJO.Product;

public class ProductTest {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
//		   ProductDao productDAO = new ProductDaoImpl();
//
//	        // Test: Add and Retrieve Product
//	        Product product = new Product("Hydrating Serum", Arrays.asList(
//	                new Ingredient("Hyaluronic Acid", 1.0),
//	                new Ingredient("Niacinamide", 5.0)
//	        ));
//	        productDAO.addProduct(product);
//	        Product retrieved = productDAO.getProductByName("Hydrating Serum");
//	        if (retrieved != null && "Hydrating Serum".equals(retrieved.getProductName())) {
//	            System.out.println("Test Add and Retrieve Product: Passed");
//	        } else {
//	            System.out.println("Test Add and Retrieve Product: Failed");
//	        }
//
//	        // Test: Get All Products
//	        Product product2 = new Product("Brightening Cream", Arrays.asList(
//	                new Ingredient("Vitamin C", 2.0)
//	        ));
//	        productDAO.addProduct(product2);
//	        List<Product> products = productDAO.getAllProducts();
//	        if (products.size() == 2) {
//	            System.out.println("Test Get All Products: Passed");
//	        } else {
//	            System.out.println("Test Get All Products: Failed");
//	        }
//
//	        // Test: Delete Product
//	        boolean deleted = productDAO.deleteProduct("Hydrating Serum");
//	        Product afterDeletion = productDAO.getProductByName("Hydrating Serum");
//	        if (deleted && afterDeletion == null) {
//	            System.out.println("Test Delete Product: Passed");
//	        } else {
//	            System.out.println("Test Delete Product: Failed");
//		ide 1: Project Introduction
//		Speaker:
		
		
		
		
		
//		_________________________________________________________________________________________________________________________________
//
//			Good [morning/afternoon], everyone.		
		
//   	My name is [Alsumaira khan], and I am currently pursuing [Your Course / Year] with a strong interest in 
//		software development and backend technologies.
//		Today, I’ll be presenting my Java project titled "CoreFix Derma Formulation Manager" — a Core Java
//		application for managing skincare products and their ingredients.
//		It allowed me to apply my knowledge of Java, databases, and system architecture in a meaningful way.
		
	//	"In skincare, every product is a mix of ingredients — but managing those combinations manually is hard.
//		
//		🎤 2. Purpose of Making This Project
//		Script:
//
//		The main purpose of this project is to create a system that helps skincare brands manage their products,
//		customers, and ingredient-based package formulations efficiently.
//		In the skincare industry, managing a large inventory of products and combinations can be complex.
//		My goal was to simplify this through a Java-based backend system that handles customer interactions,
//		product listings, and admin-level package customization.
		//	My project makes it simple. It's like a backend brain for a skincare business."

//
//		🎤 3. Scopes of the 
//		The scope of the project is focused on:
//
//			Customer registration, login, and shopping experience
//
//			Admin-level control for managing skincare product packages
//
//			Secure access and organized database operations through DAO
//
//			Backend management of carts, orders, and formulations
//			Although it currently works as a console-based application, the codebase is designed to be scalable, 
//			so it can be extended with a frontend or even a mobile interface later.
//
		
//		🎤 4. Features
//		Script:
//
//		This project includes the following features:
//
//		User Registration & Login for both customers and admins
//
//		View Products categorized by type or ingredients
//
//		Add to Cart and calculate total price
//
//		Place Orders and view order history
//
//		Admin Dashboard to add, update, or delete products and formulations
//
//		Package Management which allows admins to create combinations of ingredients
//		These features ensure a functional backend workflow for any skincare product system.
//		
//			Slide 2: Technologies Used
//			Speaker:
//
//			The technologies and tools used in this project are:
//
//			Core Java (OOP Concepts)
//
//			JDBC for database connectivity
//
//			MySQL as the backend database
//
//			DAO (Data Access Object) pattern for abstraction
//
//			MVC principles (lightweight implementation)
//
//			Slide 3: Project Structure
//			Speaker:
//
//			The project is divided into the following packages:
//
//			POJO (Plain Old Java Objects)
//			Contains classes for Product and Ingredient with their attributes, getters, setters, constructors, and toString() methods.
//
//			DAO Interface
//			Defines CRUD operations like addProduct(), updateProduct(), getAllProducts(), etc.
//
//			IMPL Package
//			Contains ProductDaoImpl.java, which implements all database logic using JDBC.
//
//			Utility Package
//			Provides a DBUtility class to manage database connections.
//
//			Test Package
//			Contains ProductMainTest.java, the entry point for the application — acting as the CLI menu-driven UI.
//
//			Slide 4: Key Features
//			Speaker:
//
//			Here are the key features of the application:
//
//			Add Product: Capture product name, usage, price, and multiple ingredients.
//
//			Update Product: Modify existing product details using its ID.
//
//			Delete Product: Delete product by name.
//
//			Search Product by ID or Name
//
//			List All Products: View all stored products along with ingredient details.
//
//			Slide 5: Database Tables
//			Speaker:
//
//			We use two relational tables:
//
//			Products
//
//			product_id (Primary Key)
//
//			product_name
//
//			product_usage
//
//			product_price
//
//			Ingredients
//
//			ingredient_id
//
//			product_id (Foreign Key)
//
//			name
//
//			percentage
//
//			This structure supports one-to-many relationships — one product can have many ingredients.
//
//			Slide 6: Demo Walkthrough
//			Speaker:
//
//			Let’s go through a demo of how it works:
//
//			The application starts with a menu offering options like Add, Update, Search, and Delete.
//
//			When adding a product, the system collects product details and prompts for multiple ingredients.
//
//			On selection of “List All Products”, the system displays every product with its ingredients.
//
//			The interaction is entirely through the console UI, ensuring clarity and simplicity.
//
//			Slide 7: Code Highlights
//			Speaker:
//
//			Here are some code highlights:
//
//			ProductDaoImpl.java handles SQL queries like INSERT, SELECT, UPDATE, and DELETE.
//
//			It uses PreparedStatement to prevent SQL injection.
//
//			ProductMainTest.java uses a loop to display options until the user exits.
//
//			All database operations are encapsulated within the DAO layer — this ensures code maintainability and easy future expansion (e.g., switching to a GUI).
//
//			Slide 8: Challenges Faced
//			Speaker:
//
//			A few challenges I tackled:
//
//			Setting up foreign key constraints in MySQL.
//
//			Mapping ingredient lists to products correctly.
//
//			Ensuring clean DAO separation to avoid business logic in UI.
//
//			These helped me reinforce my understanding of relational modeling and Java-JDBC integration.
//
//			Slide 9: Future Enhancements
//			Speaker:
//
//			In the future, I’d like to:
//
//			Add a GUI using JavaFX or Swing
//
//			Implement search filters by ingredient
//
//			Add data validation and error logging
//
//			Export product lists to PDF/CSV reports
// 
//			Slide 10: Conclusion
//			Speaker:
//
//			To conclude:
//
//			This project shows how Core Java can be used to build a fully functional, modular, and scalable application.
//
//			It helped me gain hands-on experience with JDBC, object-oriented design, and backend database handling.
//	        }
	    }
	}