package Test;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

import DAO.ProductDao;
import IMPL.ProductDaoImpl;
import POJO.Ingredient;
import POJO.Product;

public class ProductMainTest {

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        ProductDao pdimpl = new ProductDaoImpl();
        int choice;

        do {
            System.out.println("\n--- CoreFix Derma Formulation Manager ---");
            System.out.println("1. Add Product");
            System.out.println("2. Update Product");
            System.out.println("3. Delete Product");
            System.out.println("4. Search Product By ID");
            System.out.println("5. List All Products");
            System.out.println("6. Search Product By Name");
            System.out.println("0. Exit");
            System.out.print("\nEnter your choice: ");
            choice = sc.nextInt();
            sc.nextLine(); 

            switch (choice) {
                case 1: 
                	// Add Product
                    System.out.print("Enter Product Name: ");
                    String name = sc.nextLine();
                    System.out.print("Enter Product Usage: ");
                    String usage = sc.nextLine();
                    System.out.print("Enter Product Price: ");
                    double price = sc.nextDouble();
                    sc.nextLine();  

                    List<Ingredient> ingredients = new ArrayList<>();
                    String more;
                    do {
                        System.out.print("Enter Ingredient Name: ");
                        String ingName = sc.nextLine();
                        System.out.print("Enter Ingredient Percentage: ");
                        double perc = sc.nextDouble();
                        sc.nextLine(); 
                        ingredients.add(new Ingredient(ingName, perc));
                        System.out.print("Add another ingredient? (yes/no): ");
                        more = sc.nextLine();
                    } while (more.equalsIgnoreCase("yes"));

                    Product newProduct = new Product(name, ingredients, usage, price);
                    boolean added = pdimpl.addProduct(newProduct);
                    System.out.println(added ? "Product added successfully." : "Failed to add product.");
                    break;

                case 2:
                	// Update Product
                    System.out.print("Enter Product ID to update: ");
                    int updateId = sc.nextInt();
                    sc.nextLine();

                    System.out.print("Enter New Product Name: ");
                    String newName = sc.nextLine();
                    System.out.print("Enter New Product Usage: ");
                    String newUsage = sc.nextLine();
                    System.out.print("Enter New Product Price: ");
                    double newPrice = sc.nextDouble();
                    sc.nextLine();

                    List<Ingredient> newIngredients = new ArrayList<>();
                    String moreIng;
                    do {
                        System.out.print("Enter Ingredient Name: ");
                        String ing = sc.nextLine();
                        System.out.print("Enter Ingredient Percentage: ");
                        double perc = sc.nextDouble();
                        sc.nextLine();
                        newIngredients.add(new Ingredient(ing, perc));
                        System.out.print("Add another ingredient? (yes/no): ");
                        moreIng = sc.nextLine();
                    } while (moreIng.equalsIgnoreCase("yes"));

                    Product updatedProduct = new Product(updateId, newName, newIngredients, newUsage, newPrice);
                    boolean updated = pdimpl.updateProduct(updatedProduct);
                    System.out.println(updated ? "Product updated successfully." : "Update failed.");
                    break;

                case 3: 
                	// Delete Product
                    System.out.print("Enter product name to delete: ");
                    String delName = sc.nextLine();
                    boolean deleted = pdimpl.deleteProduct(delName);
                    System.out.println(deleted ? "Product deleted successfully." : "Product not found.");
                    break;

                case 4:
                	// Search By ID
                    System.out.print("Enter Product ID to search: ");
                    int id = sc.nextInt();
                    sc.nextLine();
                    Product foundById = pdimpl.searchById(id);
                    if (foundById != null) {
                        System.out.println(foundById);
                    } else {
                        System.out.println("Product not found.");
                    }
                    break;

                case 5:
                	// List All Products
                    List<Product> allProducts = pdimpl.getAllProducts();
                    if (allProducts.isEmpty()) {
                        System.out.println("No products found.");
                    } else {
                        for (Product p : allProducts) {
                            System.out.println(p);
                        }
                    }
                    break;

                case 6:
                	// Search By Name
                    System.out.print("Enter product name to search: ");
                    String searchName = sc.nextLine();
                    List<Product> productsByName = pdimpl.getProductByName(searchName);
                    if (!productsByName.isEmpty()) {
                        for (Product p : productsByName) {
                            System.out.println(p);
                        }
                    } else {
                        System.out.println("Product not found.");
                    }
                    break;

                case 0:
                    System.out.println("Exiting application.");
                    break;

                default:
                    System.out.println("Invalid choice.");
            }

        } while (choice != 0);

        sc.close();
    }
}
