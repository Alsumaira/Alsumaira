package POJO;

import java.util.List;

public class Product {
	    private int ProductId;
	    private String productName;
	    private List<Ingredient> ingredients;
	    private String productusage;
	    private double productPrice;
	    
		public int getProductId() {
			return ProductId;
		}
		public void setProductId(int productId) {
			ProductId = productId;
		}
		public String getProductName() {
			return productName;
		}
		public void setProductName(String productName) {
			this.productName = productName;
		}
		public List<Ingredient> getIngredients() {
			return ingredients;
		}
		public void setIngredients(List<Ingredient> ingredients) {
			this.ingredients = ingredients;
		}
		public String getProductusage() {
			return productusage;
		}
		public void setProductusage(String productusage) {
			this.productusage = productusage;
		}
		public double getProductPrice() {
			return productPrice;
		}
		public void setProductPrice(double productPrice) {
			this.productPrice = productPrice;
		}
		@Override
		public String toString() {
			return "Product [ProductId=" + ProductId + ", productName=" + productName + ", ingredients=" + ingredients
					+ ", productusage=" + productusage + ", productPrice=" + productPrice + "]";
		}
		public Product(int productId, String productName, List<Ingredient> ingredients, String productusage,
				double productPrice) {
			super();
			ProductId = productId;
			this.productName = productName;
			this.ingredients = ingredients;
			this.productusage = productusage;
			this.productPrice = productPrice;
		}
		public Product(String productName, List<Ingredient> ingredients, String productusage, double productPrice) {
			super();
			this.productName = productName;
			this.ingredients = ingredients;
			this.productusage = productusage;
			this.productPrice = productPrice;
		}
		public Product() {
			super();
			// TODO Auto-generated constructor stub
		}
	    
	    
}