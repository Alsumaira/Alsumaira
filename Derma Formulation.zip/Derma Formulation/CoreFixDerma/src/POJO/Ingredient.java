package POJO;

public class Ingredient {
	
	    private String name;
	    private double percentage;

	    public Ingredient(String name, double percentage) {
	        this.name = name;
	        this.percentage = percentage;
	    }

	    // Getters and Setters
	    public String getName() {
	        return name;
	    }

	    public void setName(String name) {
	        this.name = name;
	    }

	    public double getPercentage() {
	        return percentage;
	    }

	    public void setPercentage(double percentage) {
	        this.percentage = percentage;
	    }

	    @Override
	    public String toString() {
	        return name + " (" + percentage + "%)";
	    }

		public Ingredient() {
			super();
			// TODO Auto-generated constructor stub
		}
	}

