package POJO;

public class Cart {

	private int cartid;
	private int productid;
	private String cEmail;
	private int pquantity;
	private String pname;
	private double pprice;
	private double totalPrice;
	public int getCartid() {
		return cartid;
	}
	public void setCartid(int cartid) {
		this.cartid = cartid;
	}
	public int getProductid() {
		return productid;
	}
	public void setProductid(int productid) {
		this.productid = productid;
	}
	public String getcEmail() {
		return cEmail;
	}
	public void setcEmail(String cEmail) {
		this.cEmail = cEmail;
	}
	public int getPquantity() {
		return pquantity;
	}
	public void setPquantity(int pquantity) {
		this.pquantity = pquantity;
	}
	public String getPname() {
		return pname;
	}
	public void setPname(String pname) {
		this.pname = pname;
	}
	public double getPprice() {
		return pprice;
	}
	public void setPprice(double pprice) {
		this.pprice = pprice;
	}
	public double getTotalPrice() {
		return totalPrice;
	}
	public void setTotalPrice(double totalPrice) {
		this.totalPrice = totalPrice;
	}
	@Override
	public String toString() {
		return "Cart [cartid=" + cartid + ", productid=" + productid + ", cEmail=" + cEmail + ", pquantity=" + pquantity
				+ ", pname=" + pname + ", pprice=" + pprice + ", totalPrice=" + totalPrice + "]";
	}
	public Cart(int cartid, int productid, String cEmail, int pquantity, String pname, double pprice,
			double totalPrice) {
		super();
		this.cartid = cartid;
		this.productid = productid;
		this.cEmail = cEmail;
		this.pquantity = pquantity;
		this.pname = pname;
		this.pprice = pprice;
		this.totalPrice = totalPrice;
	}
	public Cart(int productid, String cEmail, int pquantity, String pname, double pprice, double totalPrice) {
		super();
		this.productid = productid;
		this.cEmail = cEmail;
		this.pquantity = pquantity;
		this.pname = pname;
		this.pprice = pprice;
		this.totalPrice = totalPrice;
	}
	public Cart() {
		super();
		// TODO Auto-generated constructor stub
	}
	
	
}
