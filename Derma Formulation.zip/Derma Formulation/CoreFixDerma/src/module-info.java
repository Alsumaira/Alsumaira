/**
 * 
 */
/**
 * 
 */
module CoreFixDerma {
	requires java.sql;
}