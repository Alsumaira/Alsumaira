package IMPL;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.LinkedList;
import java.util.List; 

import DAO.CartDao;
import POJO.Cart;
import POJO.Product;
import Utility.DBUtility;

public class CartDaoImpl implements CartDao {

	Connection con=null;
	String sql;
	PreparedStatement pst=null; 	
	ResultSet rs=null;
	boolean flag;
	int row;
	List <Cart> cartlist=new LinkedList<>();
	@Override
	public boolean addToCart(Cart cart) {
		// TODO Auto-generated method stub
		Connection con=DBUtility.getConnect();
		sql="insert into cart( productid, cEmail, pquantity,  pname, pprice, totalPrice)values(?, ?, ?, ?, ?, ?)";
		
		try
		{
		   PreparedStatement pst=con.prepareStatement(sql);
		   pst.setInt(1,cart.getProductid());
		   
		   Product p=new ProductDaoImpl().searchById(cart.getProductid());
		   
		   pst.setDouble(2, p.getProductPrice());
		   pst.setInt(3, cart.getPquantity());
		   
		   double totalPrice=p.getProductPrice()*cart.getPquantity();
		   
		   pst.setDouble(4, totalPrice);
		   pst.setString(5, cart.getcEmail());
		   pst.setString(6, p.getProductName());
		   
		   
		   row=pst.executeUpdate();
		}
		catch(SQLException e)
		{
			e.printStackTrace();
		}
		if(row>0)
			return true;
		else
			return false;
	}

		
		
	@Override
	public List<Cart> showCartList() {
		Connection con=DBUtility.getConnect();
		sql="select * from cart";
		
		try
		{
			pst=con.prepareStatement(sql);
			rs=pst.executeQuery();
			
			List<Cart> clist=new LinkedList<>();
			
			while(rs.next())
			{
				Cart ca=new Cart();
				ca.setCartid(rs.getInt("cartId"));
				ca.setcEmail(rs.getString("emailId"));
				ca.setPname(rs.getString("ProductName"));
				ca.setProductid(rs.getInt("ProductId"));
				ca.setPprice(rs.getDouble("Product Price"));
				ca.setPquantity(rs.getInt("ProdutQuantity"));
				ca.setTotalPrice(rs.getDouble("totalPrice"));
				
				clist.add(ca);
			}
			return clist;
		}
		catch(SQLException e)
		{
			e.printStackTrace();
		}		return null;
	}
	@Override
	public List<Cart> searchCartByEmailId(String cEmail) {
		Connection con=DBUtility.getConnect();

         sql="select * from cart where emailId=?";
		
		try
		{
			pst=con.prepareStatement(sql);
			pst.setString(1, cEmail);
			
			rs=pst.executeQuery();
			
			List<Cart> clist=new LinkedList<>();
			
			while(rs.next())
			{
				Cart ca=new Cart();
				ca.setCartid(rs.getInt("cartId"));
				ca.setcEmail(rs.getString("emailId"));
				ca.setPname(rs.getString("ProductName"));
				ca.setProductid(rs.getInt("ProductId"));
				ca.setPprice(rs.getDouble("Product Price"));
				ca.setPquantity(rs.getInt("ProdutQuantity"));
				ca.setTotalPrice(rs.getDouble("totalPrice"));
				
				clist.add(ca);
			}
			
			return clist;
		}
		catch(SQLException e)
		{
			e.printStackTrace();
		}		return null;
	}
	@Override
	public Cart searchCartById(int cartid) {
		Connection con=DBUtility.getConnect();
        sql="select * from cart where cartId=?";
		
		try
		{
			pst=con.prepareStatement(sql);
			pst.setInt(1, cartid);
			rs=pst.executeQuery();
			
			while(rs.next())
			{
				Cart ca =new Cart();
				ca.setCartid(rs.getInt("cartId"));
				ca.setcEmail(rs.getString("emailId"));
				ca.setPname(rs.getString("ProductName"));
				ca.setProductid(rs.getInt("ProductId"));
				ca.setPprice(rs.getDouble("Product Price"));
				ca.setPquantity(rs.getInt("ProdutQuantity"));
				ca.setTotalPrice(rs.getDouble("totalPrice"));
				
				return ca;
			}
			
		}
		catch(SQLException e)
		{
		e.printStackTrace();
		}
		
		return null;
	}
	@Override
	public boolean deleteCartById(int cartid) {
		Connection con=DBUtility.getConnect();
	sql="delete from cart where cartId=?";
		
		try
		{
			pst=con.prepareStatement(sql);
			pst.setInt(1, cartid);
			row=pst.executeUpdate();
		}
		catch(SQLException e)
		{
			e.printStackTrace();
		}
		if(row>0)
			return true;
		else
		return false;
	}
	@Override
	public boolean deleteCartByEmail(String email) {
		Connection con=DBUtility.getConnect();
	sql="delete from cart where emailId=?";
		
		try
		{
			pst=con.prepareStatement(sql);
			pst.setString(1, email);
			row=pst.executeUpdate();
		}
		catch(SQLException e)
		{
			e.printStackTrace();
		}
		
		if (row>0)
			return true;
		else
		return false;
	}
	@Override
	public boolean updateCart(int cartid, int pquantity) {
		Connection con=DBUtility.getConnect();
	sql="update cart set ProductQuantity=? where cartId=?";
		
		try
		{
			pst=con.prepareStatement(sql);
			pst.setInt(1, pquantity);
			pst.setInt(2, cartid);
			row=pst.executeUpdate();
			
			if(row>0) {
				
				Cart c=searchCartById(cartid);
				
				double totalPrice=c.getPprice()*c.getPquantity();
				
				sql="update cart set totalPrice=? where cartId=?";
				try {
					pst=con.prepareStatement(sql);
					pst.setDouble(1, totalPrice);
					pst.setInt(2, cartid);
					
					int row2=pst.executeUpdate();
					
					if(row2>0)
						return true;
					
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				
				
			}
			else
				return false;
		}
		catch(SQLException e)
		{
			e.printStackTrace();
		}
		
		return false;
	}
	
}
