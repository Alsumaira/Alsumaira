package IMPL;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

import DAO.ProductDao;
import POJO.Ingredient;
import POJO.Product;
import Utility.DBUtility;

public class ProductDaoImpl implements ProductDao {

    @Override
    public boolean addProduct(Product p) {
        Connection con = DBUtility.getConnect();
        String psql = "INSERT INTO Products(product_name, product_usage, product_price) VALUES (?, ?, ?)";
        String isql = "INSERT INTO Ingredients(product_id, name, percentage) VALUES (?, ?, ?)";

        try {
            PreparedStatement pst = con.prepareStatement(psql, Statement.RETURN_GENERATED_KEYS);
            pst.setString(1, p.getProductName());
            pst.setString(2, p.getProductusage());
            pst.setDouble(3, p.getProductPrice());
            int affectedRows = pst.executeUpdate();

            if (affectedRows == 0) return false;

            ResultSet generatedKeys = pst.getGeneratedKeys();
            int productId = 0;
            if (generatedKeys.next()) {
                productId = generatedKeys.getInt(1);
            }

            for (Ingredient ing : p.getIngredients()) {
                PreparedStatement ipst = con.prepareStatement(isql);
                ipst.setInt(1, productId);
                ipst.setString(2, ing.getName());
                ipst.setDouble(3, ing.getPercentage());
                ipst.executeUpdate();
            }

            return true;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }

    @Override
    public boolean updateProduct(Product p) {
        Connection con = DBUtility.getConnect();
        String update = "UPDATE Products SET product_name = ?, product_usage = ?, product_price = ? WHERE product_id = ?";

        try {
            PreparedStatement pst = con.prepareStatement(update);
            pst.setString(1, p.getProductName());
            pst.setString(2, p.getProductusage());
            pst.setDouble(3, p.getProductPrice());
            pst.setInt(4, p.getProductId());

            return pst.executeUpdate() > 0;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }

    @Override
    public boolean deleteProduct(String name) {
        String delete = "DELETE FROM Products WHERE product_name = ?";
        try (Connection con = DBUtility.getConnect();
             PreparedStatement pst = con.prepareStatement(delete)) {

            pst.setString(1, name);
            return pst.executeUpdate() > 0;

        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }

    @Override
    public Product searchById(int productId) {
        // You can implement this based on your table structure
        return null;
    }

    @Override
    public List<Product> getAllProducts() {
        Connection con = DBUtility.getConnect();
        String search = "SELECT * FROM Products";

        List<Product> result = new ArrayList<>();
        try {
            PreparedStatement pst = con.prepareStatement(search);
            ResultSet rs = pst.executeQuery();

            while (rs.next()) {
                Product p = new Product();
                p.setProductId(rs.getInt("product_id"));
                p.setProductName(rs.getString("product_name"));
                p.setProductusage(rs.getString("product_usage"));
                p.setProductPrice(rs.getDouble("product_price"));
                p.setIngredients(new ArrayList<>());
                result.add(p);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return result;
    }

    @Override
    public List<Product> getProductByName(String name) {
        Connection con = DBUtility.getConnect();
        String search = "SELECT * FROM Products WHERE product_name = ?";
        List<Product> result = new ArrayList<>();

        try {
            PreparedStatement pst = con.prepareStatement(search);
            pst.setString(1, name);
            ResultSet rs = pst.executeQuery();

            while (rs.next()) {
                Product p = new Product();
                p.setProductId(rs.getInt("product_id"));
                p.setProductName(rs.getString("product_name"));
                p.setProductusage(rs.getString("product_usage"));
                p.setProductPrice(rs.getDouble("product_price"));
                p.setIngredients(new ArrayList<>());
                result.add(p);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return result;
    }
}
